///

Joao Francisco Lino Daniel  7578279
Mateus Agostinho dos Anjos  9298191
Matheus Oliveira            8642821
Victor Andreas Sprengel     9298002

///

PECAS

Memoria - bloco de memoria RAM do logisim, cada unidade de memoria 
possui 16 bits, e seu endereco 8 bits. O bloco de memoria RAM, proprio 
do Logisim, recebe em sua entrada de endereço (A) (8-bits) END-I ou END 
dependendo da selecao do MUX implementado. O MUX, por sua vez, escolhera 
uma das entradas a parir do comando dado, se for LDA ele carregara END-I, 
caso o comando dado for STR ele carregara END. Na entrada de armazenamento 
(D)(8-bits) a memoria recebera o valor a ser armazenado (IN), proveniente 
do acumulador. Na entrada de clock, atualizaremos a posicao da memoria a 
partir de C++, proveniente da "FASE CONVERTER", pois necessitamos de 
"tempo dobrado" para executar algumas operacoes na memória como o STA. 
Na entrada clear da memoria, ligamos diretamente o comando STP para zerar 
a memoria caso seja dado este comando. Por fim, o valor da memoria saira 
em DATA que sera carregado no ACC.

Acumulador - registrador do logisim, possui 16 bits. Recebe a data da
memoria, se LDA estiver ativo, fica liberado para ser escrito, caso contrario
nao pode ser modificado, recebe clock tambem para mante-lo sincronizado com
o sistema. O acumulador tem uma saida, que quando STA etiver ativa,
imprime seu valor no endereco de memoria.

IR - registrador do logisim, possui 16 bits. O operador IR, proveniente 
do Logisim, recebe CL (clock) como marcador de tempo e DATA (proveniente 
da memoria RAM). Apos guardar a instrucao do usuario (8 bits) e o endereço 
a ser executada (8 bits) IR repassa tais bits para o controlador, que 
selecionara qual das operacoes o usuario gostaria de executar (a partir 
do numero dado) sendo a saida uma das operações : NOP, STA, LDA, JMP 
ou STP. A saida do controlador sera uma das operacoes juntamente com END-I 
(endereço que tal operacao sera executada).

PC - contador do logisim, possui 8 bits. PC recebe END-I que sera carregado, 
caso necessario, no contador. Apos isso decidiremos se o endereço de saida 
(END) devera ser carregado ou se apenas daremos o count up para endereço 
de saida. Para isso a entrada count recebe 0 se a funcao a ser executada 
for JMP ou STP (funcoes que necessitam do carregamento de endereço) e a 
entrada LOAD recebera 1, desta forma carregaremos os dados de END-I para END, 
portanto a saida END sera igual ao END-I proveniente do control. Caso a funcao 
a ser executada nao seja JMP nem STP, a entrada LOAD recebe 0 e count recebera 
1, portanto o endereco de saida sera o proximo endereço da memoria.

Controlador - Recebe o valor de um endereco de memoria, ou seja 16
bits e decodifica este, separando os 8 primeiros como funcao e os 8
ultimos como endereco onde a fucao deve ser executada. Recebe um fio de
16 bits do IR e separa os 8 primeiros bits como sendo instrucoes e os 8
restantes como endereco.

FUNCOES

Todas as funcoes foram implementadas em 2 ciclos, ou seja, primeiramente,
a instrucao e recebida e colocada no IR, se a funcao em questao requer
movimento dentro da memoria (colocar o acc na posicao x ou o contrario)
o controlador, que alem de verificar qual e a funcao, manda sinal para 
a memoria tambem se movimentar para esa posicao neste ciclo, no segundo
ciclo caso a funcao seja sta ou lda a informacao do acc vai para o ende-
reco correto ou o contrario, e ao fim desse segundo ciclo a memoria estara
na proxima posicao, pronta para a nova instrucao.

LDA - Essa funcao carrega o dado do endereco que foi dado junto com ela
para o acumulador. Quando o pc chega numa instrucao como LDA primeiramente
essa instrucao e jogada no ir que por sua vez passa para o controlador, que
separa os bits de funcao e de endereco, uma vez sabido o endereco que devemos
extrair o conteudo, o controlador move pc para o endereco correto e libera
acesso ao acumulador, e emfim o dado e copiado.

STA - Muito similarmente ao LDA essa funcao carrega o acumulador para um
endereco especifico de memoria, quando pc chega numa instrucao como essa,
ele inicialmente manda a instrucao para o ir, que manda para o controlador,
que separa os bits e direciona pc para o endereco correto. Uma vez no endereco
correto, libera escrita na memoria e escreve o valor de acc no endereco dado.

NOP - Essa funcao simplesmente nao faz nada. O controlador percebe que e ela e
nao executa nenhuma acao.

JMP - Essa instrucao faz um pulo nao condicional para um endereco. Quando pc
chega nessa instrucao, ele manda para o ir que manda para o controlador, que
separa os bits de instrucao dos de endereco e modifica o valor de pc para o
valor especificado e portanto pula para o endereco.

STP - Essa instrucao existe para finalizar todas as acoes do sistema, portanto
uma vez lida ela move pc para a casa inicial (00), limpa a memoria e remove o 
efeito dos clocks futuros.

