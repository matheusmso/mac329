////

    Joao Francisco Lino Daniel      7578279
    Mateus dos Anjos
    Matheus Oliveira                8642821
    Victor Andreas Sprengel         9298002

////

O projeto esta implementado para realizar cinco operações:
- ADIÇÃO
- SUBTRAÇÃO
- MULTIPLICAÇÃO
- DIVISÃO
- RESTO
trabalhando com números de 8 bits e notação complemento de 2, portanto o intervalo
aceitável de números é [-128, 127].

=== ULA ===
A Unidade Lógica e Aritimética (ULA) foi implementada da seguinte forma:
Recebe como entrada dois números de 8 bits A e B e um terceiro número, este de 3
bits, para fazer o controle de operações. Como saída, a ULA tem um bit de overflow
e um número de 8 bits como resultado da operação selecionada. Importante ressaltar
que o número de resultado deve ser ignorado caso o bit de overflow esteja aceso,
pois não haverá sentido naquela quantidade.
O controle de operações segue a tabela:

        operação        |   codigo
        ADIÇÃO              000
        SUBTRACAO           001
        MULTIPLICAÇÃO       010
        DIVISAO             011
        RESTO               100

Para realizar esta tarefa, a ULA foi estruturada para receber A e B, realizar
todas as operações possíveis e, com base no controle, seleciona bit a bit as
saídas, tanto de resultado, quanto de overflow, por meio de 9 multiplexers.
Aqui, vale dizer que o multiplexer de 5 para 1 com 3 controles tem como
selecionar ate 8 fluxos de entrada, porém como so ha 5 fluxos validos, os
controles 101, 110 e 111 foram decididos para ligarem um overflow, indicando
uma operação invalida.


=== MUX ===
O Multiplexer, como citado e quase totalmente explicado na seção anterior, é
um seletor de fluxo. Para o contexto, foi implementado um multiplexer de 5 para
1 com 3 bits de controle (que seleciona ate 8 fluxos). De acordo com a tabela de
operações, ele recebe 5 bits de entrada (um de cada operação) e seleciona o bit
que corresponde à operação indicada no controle.


=== OPERAÇÕES ===
Cada operação foi implementada em um circuito independente (a menos da divisão e
resto, pois são essencialmente a mesma operação), e todas, sem exceção, contém
subciruitos.

    * ADIÇÃO *
    A adição é feita bit a bit, em ordem crescente de significância. Para a soma dos
    dois primeiros bits (os menos significantes), foi implementado um "halfAdder",
    enquanto que para os bits restantes, foi implementado um "fullAdder".

        * halfAdder *
        Este circuito recebe dois bits de entrada, que são os números a serem
        somados, e produz duas saídas, sendo uma o resultado da soma e a outra, um
        indicador de carry out. As saídas são representadas da seguinte forma:

            a   b   s   Cout
            0   0   0   0
            0   1   1   0
            1   0   1   0
            1   1   0   1

        Com essa tabela verdade, fica fácil verificar que o resultado s da soma é
        uma aplicação de um [a XOR b], enquanto que o valor de Cout é determinado
        por um [a AND b].

        * fullAdder *
        Este circuito recebe três bits de entrada, que são os dois bits a serem
        somados e um bit de carry in (advindo de uma soma de bit anterior, seja ela
        um halfAdder ou outro fullAdder), e produz duas saídas, o resultado final
        da soma e um carry out. As saídas são representadas da seguinte forma:

            a   b   Cin s   Cout
            0   0   0   0   0
            0   0   1   1   0
            0   1   0   1   0
            0   1   1   0   1
            1   0   0   1   0
            1   0   1   0   1
            1   1   0   0   1
            1   1   1   1   1

        Para atingirmos esse resultado, foi utilizado um halfAdder para somar os
        os dois bits dos números, outro halfAdder que pega o resultado do primiero
        e soma com o Cin e então temos o valor final da soma. O Cout é resultado
        de um XOR com os Couts de cada um dos halfAdders.

    Além disso, temos tambem uma analise especial para o Overflow da ADIÇÃO, que
    foi implementado analisando os carries do ultimo bit, tanto Cin, quanto Cout.
    Notou-se que quando esses carries eram iguais, não havia ocorrido um overflow;
    já, quando eram diferentes, o overflow tinha ocorrido. Então, de acordo com
    isso, implementou-se um XOR que recebe esses bits como entrada para obter-se a
    verificação de Overflow na ADIÇÃO



    * SUBTRACAO *
    Para realizar a subtração, foi implementado um circuito baseado em ADIÇÃO, que
    ao invés de realizar A - B, opera considerando a seguinte adição: A + (-B).
    Como, para o sistema, foi adotado a notação de Complemento de 2, este circuito
    foi implementado.

        * Comp2 *
        Este circuito implementa ipsis literis a definição do complemento de dois:
        Dado um número A, seu oposto, denotado por -A, é definido pela soma de 1
        à negação de A. Então, o circuito recebe uma entrada de 8 bits, calcula
        sua negação e então realiza uma adição com uma constante 00000001. Neste
        caso, o overflow da adição e ignorado.

    Os cuidados com o Overflow na subtração são exatamente os mesmos da ADIÇÃO,
    explicados anteriormente.


  	* MULTIPLICAÇÃO *
    Esta operação foi separada em partes: a primeira dedicada ao cálculo da
    magnitude do  resultado, a segunda voltada ao estudo do sinal. Para a primeira,
    foi implementado um circuito "absoluteValue".

        * absoluteValue *
        Este circuito calcula o módulo de um número de entrada, ou seja, sua saída
        é exatamente igual a entrada caso o número seja positivo, ou saída é o
        oposto da entrada, caso contrário. Nesse caso, o oposto e calculado com o
        circuito "comp2" explicado acima.

    Entao, submete-se ambas as entrada a este circuito absoluteValue e a conta em
    si e realizada em unsignedMultiplication

        * unsignedMultiplication *
        Este circuito implementa o algoritmo da multiplicação. No caso, utiliza-se
        números de 8bits, então a multiplicação de A por B e entendida como 7
        mulitplicacoes menores de A por bi, onde bi e o i-esimo dígito de B. Para
        tal operação, foi implementado um circuito chamado "A*b (one bit
        multiplication)"

            * A*b (one bit multiplication) *
            Seguindo a tabela verdade da multiplicação de bits, a implementação
            deste circuito é trivial:

                a   b   p
                0   0   0
                0   1   0
                1   0   0
                1   1   1

            Nota-se que esta operação equivale à operação AND. E eis o circuito:
            recebe como entrada um número A de 8 bits e um bit b de outro número,
            realiza ai AND b (ai := i-esimo dígito do número A de 8 bits), e tem-se
            o si (i-esimo dígito da saída).

        Além disso, o resultado de cada operação do circuito anterior tem que ser
        deslocado um bit para a esquerda, para então poder ser feita a adição dos
        produtos parciais. Para isso, foi implementado o circuito "<<< (shift left
        once)".

            * <<< (shift left once) *
            Este circuito é bastante simples: ele apenas opera uma multiplicação
            de uma entrada por 2. Note que, como as operações estao representadas
            em base 2, essa operação é trivial: apenas desloca-se cada bit uma
	    unidade para a esquerda. Por exemplo, 00010110 operado em shift left
	    produz 00101100.
            Nesta operação, temos que ter cuidado com um Overflow, que ocorre
            quando o bit mais significativo da entrada é um, pois, ao ser deslocado
            à esquerda, ele cairia no 8o bit - que sabemos representar o sinal, já
            que usamos notação complemento de 2.

    A segunda parte, dedicada ao estudo do sinal, analisa se os sinais das entradas
    são iguais - e então o resultado é positivo -, ou se são diferentes - produzindo
    uma resposta negativa. Neste trecho do circuito, foi identificado que poderia
    usar a seguinte expressão:
    Sejam a7 e b7 os dígitos mais significativos de cada entrada e R a saída do
    circuito unsignedMultiplication. A resposta final será denotada por S, ~X é a
    negação de X, -Y é o oposto de Y (complemento de 2).

        S = (R AND ~(a7 XOR b7)) OR (-R AND (a7 XOR b7))


    * DIVISÃO (quociente e resto) *
    A divisão tem um esquema parecido com a multiplicação, explicada acima, no que
    tange a divisão das tarefas. A operação tem duas partes, uma dedicada ao sinal,
    outra dedicada a magnitude do resultado. O estudo do sinal desta operação foi
    implementado da mesma forma que o da multiplicação - já explicado.
    Ainda a parte dedicada à magnitude do quociente é muito similar a multiplicação:
    a conta em si é feita em módulo, então o circuito absoluteValue e novamente
    utilizado para ambas as entradas; tendo como entrada os fluxos que saem dos
    absoluteValues, a operação em si é feita em unsignedDivision.

        * unsignedDivision *
        Este circuito recebe dois números A e B de entrada e cuida das sucessivas
        subtrações, implementadas em divisionSub.

            * divisionSub *
            Este circuito recebe dois números A e B como entrada e tenta realizar
            a subtração A - B. Caso seja possível, ou seja, caso A >= B, o circuito
            devolve o resultado da subtração e um bit aceso indicando que foi possível
            operar. Caso contrário, retorna A e um bit apagado indicando não ter
            operado.

        Cada uma das subtrações é feita da seguinte forma: a primeira subtração tem
        como entrada o bit mais significativo de A completado com zeros à esquerda, e
        B; as demais recebem a saída da operação anterior deslocadas para a esquerda
        complementadas pelo proximo bit mais significativo de A.
        Esses bits independentes compõem o quociente da divisão, enquanto que o resto
        é identificado na saída da última divisionSub.
            

    O Overflow da divisão ocorre somente quando o divisor é zero. Portanto, quando
    o divisor for zero, a saída de Overflow estará ligada tanto para a operação
    quociente, quanto para a operação resto da divisão.







